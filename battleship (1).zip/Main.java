class Main {
  public static void main(String[] args) {
    Grid grid = new Grid();
    grid.display();
    System.out.println();
    System.out.print(grid.haveSpace(2,3,2));
  }
}