public class Grid {
  private boolean[][] grid;
  
  public Grid() {
    grid = new boolean[10][10];
//for testing:
    grid[3][3] = true;
    
  }

  public void printLine() {
    System.out.println("--------------------------------");
  }
  public void printLetter(int row) {
    String[] arr = new String[]{"J", "I", "H", "G", "F", "E", "D", "C", "B", "A"};
    System.out.print(arr[row]);
  }

  public void printNum() {
    int[] arr = new int[]{0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
    for(int i = 0; i < arr.length; i++) { 
      System.out.print(" " + arr[i] + " ");
    }//add a println here to clear your output
  }

  public void printRow(int row) {
    System.out.print("| ");
    for(int col = 0; col < grid[row].length; col++) {
      if(grid[row][col]) {
        System.out.print("*" + "| ");
      }
      else {
        System.out.print(" | ");
      }
      if(col == 9) {
        System.out.println();
        printLine();
        //System.out.print("   ");
      }
    }
  }
  
  public void display() {
    printLine();
    //System.out.print("  ");
    for(int row = 0; row < grid.length; row++) {
      printLetter(row);
      printRow(row);
    }
    System.out.print("  ");
    printNum();
  }
  /*
  public void populater(int size, int count) {
    if(haveSpace(size, r, c)) {
      int i = 0;
      while(i < size) {
        grid[r][c + i] = true;
        i++;
      }
    }
  }
  */
  //note: check if it goes of the grid
  //
  public boolean haveSpace(int size, int r, int c) {
   /* printRow(r-1);
    printRow(r);
    printRow(r+1);
    System.out.println("placing "+size+" at "+r+","+c);
    */
    if(c > 10-size) {//why check row? we are strictly horiz!
      return false;
    }
    while(size > 0) {
      if(grid[r][c + size -1]) { // it is tru when there is a ship
        return false;
      }
      
      size--;
    }
    return true;
  }
  public boolean hit(char rowLabel, int col) {
    if(grid[rowLabel][col]) {
      grid[rowLabel][col] = false;
      return true;
      
    }
    return false;
  }
}